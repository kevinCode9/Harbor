import { useCallback, useState } from 'react';

function stripKeyFromUrl() {
  const url = new URL(window.location.href);
  if (!url.searchParams.has('key')) return;
  url.searchParams.delete('key');
  const next = `${url.pathname}${url.search}${url.hash}`;
  window.history.replaceState({}, '', next);
}

export function useAdminAuth() {
  const [authenticated, setAuthenticated] = useState(false);
  const [adminKey, setAdminKey] = useState('');

  const login = useCallback(async (key?: string) => {
    const value = (key ?? adminKey).trim();
    if (!value) {
      setAuthenticated(false);
      return false;
    }
    try {
      const response = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: value }),
      });
      const data = await response.json().catch(() => ({ ok: false }));
      const ok = Boolean(data.ok);
      setAuthenticated(ok);
      if (ok) {
        stripKeyFromUrl();
        setAdminKey('');
      }
      return ok;
    } catch {
      setAuthenticated(false);
      return false;
    }
  }, [adminKey]);

  return {
    authenticated,
    adminKey,
    setAdminKey,
    login,
    logout: () => {
      setAuthenticated(false);
    },
  };
}
