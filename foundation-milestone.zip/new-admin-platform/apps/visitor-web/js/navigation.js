import { previewHref } from './session.js';

export function go(path) {
  window.location.href = path;
}

function appliedFrom(source) {
  if (!source || typeof source !== 'object') return { page: '', params: {}, at: '' };
  const applied = source.applied && typeof source.applied === 'object' ? source.applied : null;
  const metadata = source.metadata && typeof source.metadata === 'object' ? source.metadata : null;
  const stored = metadata && metadata.applied && typeof metadata.applied === 'object' ? metadata.applied : null;
  const record = applied || stored || {};
  const params = record.appliedParameters && typeof record.appliedParameters === 'object' ? record.appliedParameters : {};
  const page = String(source.page || source.current_page || source.currentPage || record.currentPage || '');
  return { page, params, at: String(record.at || source.at || '') };
}

/** Page plus the Default/Invalid (and hold) state from the latest Send. */
export function sendDestination(page, params) {
  const path = String(page || '');
  const query = new URLSearchParams();
  if (params && (params.view === 'invalid' || params.view === 'default')) query.set('view', params.view);
  if (params && params.hold === true) query.set('hold', '1');
  const search = query.toString();
  return search ? `${path}?${search}` : path;
}

/**
 * Prefer WebSocket session:command (Send/end). Keep HTTP presence poll as fallback
 * when the socket is unavailable. Preview never emits session:command.
 * Same-page Send still applies when Default/Invalid changes.
 */
export function watchAdminSend(heartbeat, currentPage, allowed, socket) {
  let navigating = false;
  let seenAt = '';

  const follow = (source) => {
    if (navigating || !source) return;
    const { page, params, at } = appliedFrom(source);
    if (!page || !allowed.includes(page)) return;
    const href = sendDestination(page, params);
    const here = `${window.location.pathname}${window.location.search}`;
    if (href !== here) {
      navigating = true;
      go(href);
      return;
    }
    if (at && seenAt && at !== seenAt) {
      navigating = true;
      window.location.reload();
      return;
    }
    if (at) seenAt = at;
  };

  if (socket) {
    socket.on('session:command', (payload) => {
      if (!payload || payload.action === 'preview') return;
      follow(payload);
    });
  }

  setInterval(async () => {
    const data = await heartbeat();
    follow(data.session);
  }, 2500);
}

export function goPreview(path) {
  go(previewHref(path));
}
