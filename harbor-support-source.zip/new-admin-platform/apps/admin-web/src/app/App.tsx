import { useEffect, useMemo, useState } from 'react';
import {
  canSendSessionAction,
  createEmptyAdminDraft,
  normalizeSessionPage,
  sanitizeAdminKeyInput,
  selectDraftAction,
  selectDraftPage,
  type AdminDraft,
} from '@shared';
import { LoginPanel } from '../pages/AdminLogin/AdminLoginPage';
import { AdminShell } from '../components/layout/AdminLayout';
import { PreviewFrame } from '../components/layout/PreviewFrame';
import { TopStatus } from '../components/layout/TopStatus';
import { SessionBoard } from '../components/sessions/SessionBoard';
import { SessionWorkspace } from '../components/sessions/SessionWorkspace';
import { SettingsPanel, type PanelSettings } from '../pages/Settings/SettingsPage';
import { useAdminAuth } from '../hooks/useAdminAuth';
import { useAdminSessions } from '../hooks/useAdminSessions';
import { defaultSettings } from '../lib/settings';
import { PREVIEW_SESSION, isPreviewSession } from '../lib/previewSession';

export default function App() {
  const [view, setView] = useState<'panel' | 'settings'>('settings');
  const [focusedToken, setFocusedToken] = useState<string | null>(null);
  const [adminDraft, setAdminDraft] = useState<AdminDraft>(() => createEmptyAdminDraft('/welcome'));
  const [settings, setSettings] = useState<PanelSettings>(defaultSettings);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const { authenticated, adminKey, setAdminKey, login } = useAdminAuth();
  const { sessions } = useAdminSessions(focusedToken);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlKey = sanitizeAdminKeyInput(params.get('key'));
    if (urlKey) {
      setAdminKey(urlKey);
      void login(urlKey);
    }
    // Initial sign-in only.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    fetch('/api/admin/settings')
      .then((r) => r.json())
      .then((data) => {
        if (data.ok) setSettings({ ...defaultSettings, ...data.settings });
      })
      .catch(() => undefined);
  }, []);

  const focused = useMemo(() => {
    if (isPreviewSession(focusedToken)) return PREVIEW_SESSION;
    return sessions.find((session) => session.token === focusedToken) ?? null;
  }, [sessions, focusedToken]);

  const cardSessions = sessions;

  const openPanelCards = () => {
    setFocusedToken(null);
    setView('panel');
    setAdminDraft((prev) => selectDraftAction(prev, 'preview'));
  };

  const openPagePreview = (page: string) => {
    const nextPage = normalizeSessionPage(page);
    setAdminDraft((prev) => selectDraftAction(selectDraftPage(prev, nextPage), 'preview'));
    setPreviewUrl(nextPage);
  };

  const sendToPage = async (page: string) => {
    if (!focused || isPreviewSession(focused.token)) return;
    if (!canSendSessionAction(focused.status)) return;
    const nextDraft = selectDraftAction(selectDraftPage(adminDraft, normalizeSessionPage(page)), 'send');
    setAdminDraft(nextDraft);
    const response = await fetch('/api/admin/command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sessionToken: focused.token,
        action: 'send',
        page: nextDraft.selectedPage,
        selectedFamily: nextDraft.selectedFamily,
        temporaryParameters: nextDraft.temporaryParameters,
      }),
    });
    const data = await response.json();
    if (!data.ok) return;
    setAdminDraft((prev) => ({
      ...prev,
      selectedPage: normalizeSessionPage(data.applied?.currentPage || nextDraft.selectedPage),
      selectedAction: null,
    }));
  };

  const patchDemoFields = async (fields: { location: string; time: string; name: string }) => {
    if (!focused || isPreviewSession(focused.token)) return;
    await fetch(`/api/admin/sessions/${focused.token}/demo-fields`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(fields),
    });
  };

  const saveSettings = async (next?: PanelSettings) => {
    await fetch('/api/admin/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(next ?? settings),
    });
  };

  const closeSession = async (token: string) => {
    if (isPreviewSession(token)) {
      setFocusedToken(null);
      return;
    }
    await fetch(`/api/admin/sessions/${token}/end`, { method: 'POST' });
    if (focusedToken === token) setFocusedToken(null);
  };

  if (!authenticated) {
    return <LoginPanel adminKey={adminKey} onKeyChange={setAdminKey} onLogin={() => void login()} />;
  }

  return (
    <AdminShell
      view={view}
      onView={(next) => {
        if (next === 'panel') setFocusedToken(null);
        setView(next);
      }}
    >
      {view === 'settings' ? (
        <SettingsPanel
          settings={settings}
          onChange={setSettings}
          onSave={(next) => void saveSettings(next)}
          onPreview={(url) => {
            if (url) openPagePreview(url);
            else openPanelCards();
          }}
        />
      ) : (
        <div className="panel-stage">
          {focused ? (
            <SessionWorkspace
              session={focused}
              onSend={(url) => void sendToPage(url)}
              onPreview={openPagePreview}
              onDemoFields={(fields) => void patchDemoFields(fields)}
            />
          ) : (
            <>
              <TopStatus count={cardSessions.length} enabled={settings.enabled} />
              <SessionBoard
                sessions={cardSessions}
                onView={(token) => {
                  const next = isPreviewSession(token)
                    ? PREVIEW_SESSION
                    : sessions.find((item) => item.token === token);
                  setFocusedToken(token);
                  setAdminDraft(createEmptyAdminDraft(normalizeSessionPage(next?.currentPage)));
                }}
                onClose={(token) => void closeSession(token)}
              />
            </>
          )}
        </div>
      )}
      {previewUrl ? <PreviewFrame url={previewUrl} onClose={() => setPreviewUrl(null)} /> : null}
    </AdminShell>
  );
}
