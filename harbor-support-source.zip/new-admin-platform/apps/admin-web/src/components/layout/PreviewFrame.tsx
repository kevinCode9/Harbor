import { useEffect } from 'react';
import { normalizeSessionPage } from '@shared';
import { previewSrc } from '../../lib/preview';

export function PreviewFrame({ url, onClose }: { url: string; onClose: () => void }) {
  const src = previewSrc(url);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div className="preview-overlay" role="dialog" aria-label="Preview">
      <button type="button" className="preview-backdrop" aria-label="Close preview" onClick={onClose} />
      <div className="preview-stage">
        <div className="preview-bar">
          <span>Preview</span>
          <small>{normalizeSessionPage(url)} — visitor is not moved</small>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Close
          </button>
        </div>
        <div className="preview-phone">
          <iframe title="Visitor preview" src={src} />
        </div>
      </div>
    </div>
  );
}
