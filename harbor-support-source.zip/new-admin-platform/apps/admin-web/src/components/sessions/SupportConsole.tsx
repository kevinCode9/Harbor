import { useEffect, useMemo, useRef, useState } from 'react';
import { PAGE_MENU, canSendSessionAction, normalizeSessionPage, presenceLabel } from '@shared';
import type { Session } from '../../lib/types';
import { screenKeyForPage } from '../../lib/safeScreens';
import { isPreviewSession } from '../../lib/previewSession';

const PAGE_HINTS: Record<string, string> = {
  '/welcome': 'Support home and consent',
  '/loading': 'Shared loading screen',
  '/waiting': 'Waiting for an agent',
  '/contact': 'Optional non-sensitive case details',
  '/success': 'Case complete',
  '/offline': 'Shown when the panel is disabled',
  '/demo/family-a/page-1': 'Account desk page 1',
  '/demo/family-a/page-2': 'Account desk page 2',
  '/demo/family-a/loading': 'Account desk loading',
  '/demo/family-b/page-1': 'Product desk page 1',
  '/demo/family-b/page-2': 'Product desk page 2',
  '/demo/family-b/loading': 'Product desk loading',
};

export function SupportConsole({
  session,
  onSend,
  onPreview,
  onDemoFields,
}: {
  session: Session;
  onSend: (url: string) => void;
  onPreview: (url: string) => void;
  onDemoFields?: (fields: { location: string; time: string; name: string }) => void;
}) {
  const groups = PAGE_MENU;
  const current = normalizeSessionPage(session.currentPage);
  const matchedFamily =
    groups.find((group) => group.pages.some((page) => normalizeSessionPage(page.url) === current))
      ?.family || groups[0]?.family || '';
  const [family, setFamily] = useState(matchedFamily);
  const [openId, setOpenId] = useState('');
  const [demoFields, setDemoFields] = useState({
    location: session.demoLocation || '',
    time: session.demoTime || '',
    name: session.demoName || session.contactName || '',
  });
  const demoTimer = useRef<number | null>(null);

  useEffect(() => {
    setFamily(matchedFamily);
  }, [matchedFamily]);

  useEffect(() => {
    setDemoFields({
      location: session.demoLocation || '',
      time: session.demoTime || '',
      name: session.demoName || session.contactName || '',
    });
  }, [session.token, session.demoLocation, session.demoTime, session.demoName, session.contactName]);

  const active = useMemo(
    () => groups.find((group) => group.family === family) ?? groups[0],
    [groups, family],
  );

  const connected = session.status === 'connected';
  const previewOnly = isPreviewSession(session.token);
  const canSend = !previewOnly && canSendSessionAction(session.status);
  const deviceLine = [session.device, session.browser].filter(Boolean).join(', ') || 'Desktop browser';
  const ipLine = `${session.ip || 'unknown'}${session.location ? ` (${session.location})` : ''}`;

  const changeDemo = (next: { location: string; time: string; name: string }) => {
    setDemoFields(next);
    if (previewOnly || !onDemoFields) return;
    if (demoTimer.current) window.clearTimeout(demoTimer.current);
    demoTimer.current = window.setTimeout(() => onDemoFields(next), 250);
  };

  return (
    <section className="session-workspace">
      <aside className="session-meta-col">
        <div className={`status ${connected ? '' : 'waiting'}`}>
          <span className="dot">●</span>
          {presenceLabel(session.status)}
        </div>

        <label className="meta-row">
          <span>Page</span>
          <input readOnly value={screenKeyForPage(session.currentPage)} />
        </label>
        <label className="meta-row">
          <span>IP</span>
          <input readOnly value={ipLine} />
        </label>
        <label className="meta-row">
          <span>Device</span>
          <input readOnly value={deviceLine} />
        </label>
        <label className="meta-row">
          <span>User Agent</span>
          <input readOnly value={session.browser || 'n/a'} />
        </label>
        {session.caseNumber ? (
          <label className="meta-row">
            <span>Case</span>
            <input readOnly value={session.caseNumber} />
          </label>
        ) : null}
      </aside>

      <div className="session-actions-col">
        <div className="chip-grid">
          {groups.map((group) => (
            <button
              key={group.family}
              type="button"
              className={`chip ${group.family === family ? 'on' : ''}`}
              onClick={() => setFamily(group.family)}
            >
              {group.family}
            </button>
          ))}
        </div>

        <div className="accordion-list">
          {(active?.pages || []).map((page) => {
            const url = normalizeSessionPage(page.url);
            const applied = current === url;
            const expanded = openId === page.id;
            const showDemoFields = page.id === 'contact' || page.id === 'family-a-2' || page.id === 'case-review';
            return (
              <div key={page.id} className={`accordion-item ${expanded ? 'open' : ''} ${applied ? 'applied' : ''}`}>
                <button
                  type="button"
                  className="accordion-hit"
                  onClick={() => setOpenId(expanded ? '' : page.id)}
                >
                  <span>
                    <span className="accordion-title">{page.name}</span>
                    <span className="accordion-hint">{PAGE_HINTS[url] || url}</span>
                  </span>
                  <span className={`settings-chevron ${expanded ? 'open' : ''}`}>▾</span>
                </button>
                {expanded ? (
                  <div className="accordion-body">
                    {showDemoFields ? (
                      <div className="demo-fields">
                        <label>
                          <span>Location</span>
                          <input
                            value={demoFields.location}
                            onChange={(e) => changeDemo({ ...demoFields, location: e.target.value })}
                            placeholder="City, Region"
                          />
                        </label>
                        <label>
                          <span>Time</span>
                          <input
                            value={demoFields.time}
                            onChange={(e) => changeDemo({ ...demoFields, time: e.target.value })}
                            placeholder="Local time"
                          />
                        </label>
                        <label>
                          <span>Name</span>
                          <input
                            value={demoFields.name}
                            onChange={(e) => changeDemo({ ...demoFields, name: e.target.value })}
                            placeholder="Display name"
                          />
                        </label>
                      </div>
                    ) : null}
                    <div className="accordion-actions">
                      <button
                        type="button"
                        className="btn-send"
                        disabled={!canSend}
                        onClick={() => {
                          if (!canSend) return;
                          onSend(url);
                        }}
                      >
                        Send
                      </button>
                      <button type="button" className="btn-preview" onClick={() => onPreview(url)}>
                        Preview
                      </button>
                    </div>
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
