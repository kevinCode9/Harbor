import { useCallback, useState } from 'react';

function stripKeyFromUrl() {
  const url = new URL(window.location.href);
  if (!url.searchParams.has('key')) return;
  url.searchParams.delete('key');
  const next = `${url.pathname}${url.search}${url.hash}`;
  window.history.replaceState({}, '', next);
}

export function useAdminAuth() {
  const [authenticated, setAuthenticated] = useState(false);
  const [adminKey, setAdminKey] = useState('');

  const login = useCallback(async (key?: string) => {
    const value = (key ?? adminKey).trim();
    if (!value) {
      setAuthenticated(false);
      return false;
    }
    const response = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: value }),
    });
    const data = await response.json().catch(() => ({ ok: false }));
    const ok = Boolean(data.ok);
    setAuthenticated(ok);
    if (ok) {
      // Key must not remain in the URL or in React state after login.
      stripKeyFromUrl();
      setAdminKey('');
    }
    return ok;
  }, [adminKey]);

  return { authenticated, adminKey, setAdminKey, login };
}
