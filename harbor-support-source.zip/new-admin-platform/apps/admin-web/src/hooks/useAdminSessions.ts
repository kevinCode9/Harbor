import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { mergeSessionRow } from '@shared';
import type { Session } from '../lib/types';

function asSessions(payload: unknown): Session[] | null {
  if (Array.isArray(payload)) return payload as Session[];
  if (payload && typeof payload === 'object' && Array.isArray((payload as { sessions?: unknown }).sessions)) {
    return (payload as { sessions: Session[] }).sessions;
  }
  return null;
}

export function useAdminSessions(_focusedToken: string | null) {
  const [sessions, setSessions] = useState<Session[]>([]);

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      const response = await fetch('/api/admin/session-list');
      const data = await response.json().catch(() => null);
      if (!cancelled && data?.ok && Array.isArray(data.sessions)) {
        setSessions(data.sessions);
      }
    };

    void load();

    const socket = io({ path: '/socket.io', transports: ['websocket', 'polling'] });
    socket.emit('admin:join');
    socket.on('sessions:updated', (payload: unknown) => {
      const next = asSessions(payload);
      if (next) setSessions(next);
    });
    socket.on('session:patch', (patch: Session) => {
      if (patch?.token) setSessions((prev) => mergeSessionRow(prev, patch));
    });

    const timer = window.setInterval(() => {
      void load();
    }, 8000);

    return () => {
      cancelled = true;
      window.clearInterval(timer);
      socket.close();
    };
  }, []);

  return { sessions };
}
