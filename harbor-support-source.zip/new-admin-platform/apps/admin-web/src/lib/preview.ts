import { normalizeSessionPage } from '@shared';

export function previewSrc(page: string) {
  const path = normalizeSessionPage(page);
  return `${path}?preview=1`;
}
