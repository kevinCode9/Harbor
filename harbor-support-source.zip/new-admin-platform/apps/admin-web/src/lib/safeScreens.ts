export type SafeClientScreen = {
  id: string;
  key: string;
  label: string;
  description: string;
  url: string;
};

/** Safe support destinations only — no credential / secret screens. */
export const SAFE_CLIENT_SCREENS: SafeClientScreen[] = [
  {
    id: 'welcome',
    key: 'WELCOME',
    label: 'WELCOME',
    description: 'Intro + consent',
    url: '/welcome',
  },
  {
    id: 'case-code',
    key: 'CASE_CODE',
    label: 'CASE_CODE',
    description: 'Non-sensitive support ID',
    url: '/loading',
  },
  {
    id: 'account-review',
    key: 'ACCOUNT_REVIEW',
    label: 'ACCOUNT_REVIEW',
    description: 'Issue details only',
    url: '/contact',
  },
  {
    id: 'waiting',
    key: 'WAITING',
    label: 'WAITING',
    description: 'Please wait',
    url: '/waiting',
  },
  {
    id: 'success',
    key: 'SUCCESS',
    label: 'SUCCESS',
    description: 'Session complete',
    url: '/success',
  },
];

export function screenKeyForPage(page?: string | null): string {
  const value = String(page || '').replace(/\/$/, '') || '/welcome';
  const match = SAFE_CLIENT_SCREENS.find((screen) => screen.url === value);
  if (match) return match.key;
  return value.replace(/^\//, '').replace(/\//g, '_').toUpperCase() || 'WELCOME';
}
