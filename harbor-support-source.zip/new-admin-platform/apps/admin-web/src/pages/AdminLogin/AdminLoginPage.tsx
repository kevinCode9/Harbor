export function LoginPanel({
  adminKey,
  onKeyChange,
  onLogin,
}: {
  adminKey: string;
  onKeyChange: (value: string) => void;
  onLogin: () => void;
}) {
  return (
    <div className="login login-sign-in">
      <form
        className="login-card"
        onSubmit={(e) => {
          e.preventDefault();
          onLogin();
        }}
      >
        <h1>Sign in</h1>
        <label className="login-key">
          <span className="login-lock" aria-hidden="true">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <rect x="5" y="11" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.8" />
              <path d="M8 11V8a4 4 0 0 1 8 0v3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </span>
          <input
            type="password"
            value={adminKey}
            onChange={(e) => onKeyChange(e.target.value)}
            placeholder=""
            autoComplete="off"
            aria-label="Admin key"
          />
        </label>
        <button type="submit" className="login-continue">
          Continue
        </button>
        <div className="login-connected">
          <span className="dot">●</span>
          Connected
        </div>
      </form>
    </div>
  );
}
