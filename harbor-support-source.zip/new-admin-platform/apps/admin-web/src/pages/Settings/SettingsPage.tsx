import { useEffect, useMemo, useState } from 'react';
import { PAGE_MENU, normalizeSessionPage } from '@shared';

export type PanelSettings = {
  enabled: boolean;
  notifications: boolean;
  startingPage: string;
  sessionTimeoutMinutes: number;
  sound: boolean;
  theme: string;
};

const PAGE_HINTS: Record<string, string> = {
  '/welcome': 'First page after visiting the panel',
  '/loading': 'Shared loading screen',
  '/waiting': 'Waiting for an agent',
  '/contact': 'Optional contact details',
  '/success': 'Case complete',
  '/offline': 'Shown when the panel is disabled',
  '/demo/family-a/page-1': 'Account desk page 1',
  '/demo/family-a/page-2': 'Account desk page 2',
  '/demo/family-a/loading': 'Account desk loading',
  '/demo/family-b/page-1': 'Product desk page 1',
  '/demo/family-b/page-2': 'Product desk page 2',
  '/demo/family-b/loading': 'Product desk loading',
};

export function SettingsPanel({
  settings,
  onChange,
  onSave,
  onPreview,
}: {
  settings: PanelSettings;
  onChange: (next: PanelSettings) => void;
  onSave: (next?: PanelSettings) => void;
  onPreview?: (url?: string) => void;
}) {
  const groups = PAGE_MENU;
  const starting = normalizeSessionPage(settings.startingPage);
  const matchedFamily =
    groups.find((group) => group.pages.some((page) => normalizeSessionPage(page.url) === starting))
      ?.family || groups[0]?.family || '';
  const [family, setFamily] = useState(matchedFamily);
  const [openId, setOpenId] = useState('');

  useEffect(() => {
    setFamily(matchedFamily);
  }, [matchedFamily]);

  const active = useMemo(
    () => groups.find((group) => group.family === family) ?? groups[0],
    [groups, family],
  );

  const commit = (next: PanelSettings) => {
    onChange(next);
    onSave(next);
  };

  return (
    <section className="settings settings-firstpage">
      <div className="settings-card">
        <div className="settings-row">
          <div>
            <div className="settings-title">Enable Panel</div>
            <div className="settings-hint">Panel will redirect when disabled</div>
          </div>
          <Toggle on={settings.enabled} onClick={() => commit({ ...settings, enabled: !settings.enabled })} />
        </div>
      </div>

      <div className="settings-card">
        <div className="settings-row">
          <div>
            <div className="settings-title">Notification Sounds</div>
            <div className="settings-hint">Sounds will play when notifications are received</div>
          </div>
          <Toggle on={settings.sound} onClick={() => commit({ ...settings, sound: !settings.sound })} />
        </div>
      </div>

      <div className="settings-card settings-initial">
        <div className="settings-initial-head">
          <div className="settings-title">Initial page</div>
          <div className="settings-hint">First page after visiting the panel</div>
        </div>

        <div className="chip-grid">
          {groups.map((group) => (
            <button
              key={group.family}
              type="button"
              className={`chip ${group.family === family ? 'on' : ''}`}
              onClick={() => setFamily(group.family)}
            >
              {group.family}
            </button>
          ))}
        </div>

        {(active?.pages || []).map((page) => {
          const url = normalizeSessionPage(page.url);
          const selected = starting === url;
          const expanded = openId === page.id;
          return (
            <div key={page.id} className={`accordion-item ${expanded ? 'open' : ''} ${selected ? 'applied' : ''}`}>
              <button
                type="button"
                className="accordion-hit"
                onClick={() => setOpenId(expanded ? '' : page.id)}
              >
                <span>
                  <span className="accordion-title">{page.name}</span>
                  <span className="accordion-hint">{PAGE_HINTS[url] || url}</span>
                </span>
                <span className={`settings-chevron ${expanded ? 'open' : ''}`}>▾</span>
              </button>
              {expanded ? (
                <div className="accordion-body">
                  <div className="accordion-actions">
                    <button
                      type="button"
                      className="btn-send"
                      onClick={() => commit({ ...settings, startingPage: url })}
                    >
                      Select
                    </button>
                    <button type="button" className="btn-preview" onClick={() => onPreview?.(url)}>
                      Preview
                    </button>
                  </div>
                </div>
              ) : null}
            </div>
          );
        })}
      </div>
    </section>
  );
}

function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      className={`settings-toggle ${on ? 'on' : ''}`}
      onClick={onClick}
      aria-pressed={on}
    >
      <span />
    </button>
  );
}
