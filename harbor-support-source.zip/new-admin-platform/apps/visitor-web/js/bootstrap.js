import { getOrCreateToken, currentPath, buildSessionState, joinSession, isPreviewMode } from './session.js';
import { startPresence } from './presence.js';
import { go, goPreview, watchAdminSend } from './navigation.js';
import { connectVisitorSocket } from './websocket.js';

export const ALLOWED_PAGES = [
  '/welcome',
  '/loading',
  '/waiting',
  '/contact',
  '/success',
  '/offline',
  '/demo/family-a/page-1',
  '/demo/family-a/page-2',
  '/demo/family-a/loading',
  '/demo/family-b/page-1',
  '/demo/family-b/page-2',
  '/demo/family-b/loading',
];

export async function bootstrapVisitor(onReady) {
  if (isPreviewMode()) {
    if (typeof onReady === 'function') {
      await onReady({
        token: 'preview',
        page: currentPath(),
        session: null,
        heartbeat: async () => ({ ok: true, preview: true }),
        go: goPreview,
        preview: true,
      });
    }
    return { offline: false, preview: true, token: 'preview', page: currentPath(), go: goPreview };
  }

  const token = getOrCreateToken();
  const page = currentPath();
  const state = buildSessionState(token, page);
  const data = await joinSession(state);

  if (data.offline) {
    return { offline: true, token, page };
  }

  const heartbeat = startPresence(token, page);
  const socket = await connectVisitorSocket(token);
  watchAdminSend(heartbeat, page, ALLOWED_PAGES, socket);

  if (typeof onReady === 'function') {
    await onReady({
      token,
      page,
      session: data.session,
      heartbeat,
      go,
    });
  }

  return { offline: false, token, page, session: data.session, heartbeat, go };
}

export function setBanner() {
  const el = document.getElementById('training-banner');
  if (!el) return;
  if (isPreviewMode()) {
    el.textContent = 'ADMIN PREVIEW — visitor is not moved. This view does not join a session.';
    return;
  }
  el.textContent =
    'TRAINING SIMULATION — Do not enter real passwords, recovery phrases, private keys, OTPs, SMS/TOTP codes, tokens, or wallet credentials. This app never copies Coinbase, Ledger, or other real company branding.';
}
