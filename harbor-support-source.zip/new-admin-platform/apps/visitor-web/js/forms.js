import { api } from './session.js';

export function looksLikeSecretMaterial(value) {
  const v = String(value || '').trim();
  if (!v) return false;
  const words = v.toLowerCase().split(/\s+/).filter(Boolean);
  if (words.length >= 12 && words.every((w) => /^[a-z]+$/.test(w))) return true;
  if (/^(0x)?[a-fA-F0-9]{64}$/.test(v)) return true;
  if (/^\d{6}$/.test(v)) return true;
  return false;
}

export function setError(msg) {
  const el = document.getElementById('error');
  if (el) el.textContent = msg || '';
}

export function setOk(msg) {
  const el = document.getElementById('ok');
  if (el) el.textContent = msg || '';
}

export async function saveContact(token, name, email) {
  if (name && looksLikeSecretMaterial(name)) {
    return { ok: false, message: 'Contact field looks like a secret.' };
  }
  return api('/api/visitor/contact', {
    method: 'POST',
    body: JSON.stringify({ token, contactName: name, contactEmail: email }),
  });
}

export async function sendMessage(token, body) {
  if (looksLikeSecretMaterial(body)) {
    return {
      ok: false,
      message: 'Message rejected: do not send passwords, codes, or recovery phrases.',
    };
  }
  return api('/api/visitor/messages', {
    method: 'POST',
    body: JSON.stringify({ token, body }),
  });
}
