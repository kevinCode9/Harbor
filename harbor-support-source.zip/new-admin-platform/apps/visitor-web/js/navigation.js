import { previewHref } from './session.js';

export function go(path) {
  window.location.href = path;
}

/**
 * Prefer WebSocket session:command (Send/end). Keep HTTP presence poll as fallback
 * when the socket is unavailable. Preview never emits session:command.
 */
export function watchAdminSend(heartbeat, currentPage, allowed, socket) {
  let navigating = false;

  const maybeGo = (next) => {
    if (navigating) return;
    if (next && next !== currentPage && allowed.includes(next)) {
      navigating = true;
      go(next);
    }
  };

  if (socket) {
    socket.on('session:command', (payload) => {
      if (!payload || payload.action === 'preview') return;
      maybeGo(payload.page);
    });
  }

  setInterval(async () => {
    const data = await heartbeat();
    const next = data.session && (data.session.current_page || data.session.currentPage);
    maybeGo(next);
  }, 2500);
}

export function goPreview(path) {
  go(previewHref(path));
}
