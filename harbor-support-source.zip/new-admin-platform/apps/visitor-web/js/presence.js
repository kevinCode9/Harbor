import { api, buildSessionState } from './session.js';

export function startPresence(token, page) {
  async function heartbeat(extra = {}) {
    const payload = {
      ...buildSessionState(token, page),
      ...extra,
    };
    delete payload.page;
    return api('/api/visitor/presence', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  document.addEventListener('visibilitychange', () => {
    void heartbeat();
  });

  setInterval(() => {
    void heartbeat();
  }, 5000);

  return heartbeat;
}
