import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import path from 'path';
import type { Express } from 'express';
import type { Server as SocketServer } from 'socket.io';
import { ALLOWED_PAGE_URLS, DEFAULT_PAGE } from './modules/pages/page.registry.js';
import { getVisitorRoot, visitorFileForUrl } from './modules/pages/page.service.js';
import { errorHandler } from './middleware/error-handler.js';
import { requestId } from './middleware/request-id.js';
import { createApiRouter } from './routes/index.js';

export function createApp(io: SocketServer, broadcastSessions: () => Promise<void>): Express {
  const app = express();
  const visitorRoot = getVisitorRoot();

  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginOpenerPolicy: false,
      crossOriginResourcePolicy: { policy: 'same-origin' },
      frameguard: { action: 'sameorigin' },
    }),
  );
  app.use(cors({ origin: true, credentials: true }));
  app.use(express.json({ limit: '32kb' }));
  app.use(morgan('dev'));
  app.use(requestId);

  app.use('/api', createApiRouter(io, broadcastSessions));

  app.use(express.static(visitorRoot));
  app.use('/public', express.static(path.join(visitorRoot, 'public')));

  for (const url of ALLOWED_PAGE_URLS) {
    app.get(url, (_req, res) => {
      res.sendFile(visitorFileForUrl(url));
    });
  }

  app.get('/', (_req, res) => {
    res.redirect(DEFAULT_PAGE);
  });

  app.use(errorHandler);
  return app;
}
