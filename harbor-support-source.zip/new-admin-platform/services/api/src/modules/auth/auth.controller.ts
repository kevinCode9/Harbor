import type { Request, Response } from 'express';
import { authenticateAdminKey } from './auth.service.js';

export function login(req: Request, res: Response) {
  const result = authenticateAdminKey(req.body?.key ?? req.query.key);
  if (!result.ok) {
    const status = result.message === 'Invalid admin key' ? 401 : 400;
    return res.status(status).json(result);
  }
  return res.json(result);
}
