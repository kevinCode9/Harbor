import { ADMIN_KEY } from '../../config/env.js';
import { sanitizeAdminKeyInput } from '../pages/page.registry.js';

export function getConfiguredAdminKey(): string {
  return sanitizeAdminKeyInput(ADMIN_KEY);
}
