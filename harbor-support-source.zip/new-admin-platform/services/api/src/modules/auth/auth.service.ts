import { z } from 'zod';
import { sanitizeAdminKeyInput } from '../pages/page.registry.js';
import { getConfiguredAdminKey } from './auth.repository.js';
import type { AdminAuthResult } from './auth.types.js';

const adminAuthSchema = z.object({
  key: z.string().min(4),
});

export function authenticateAdminKey(rawKey: unknown): AdminAuthResult {
  const suppliedKey = sanitizeAdminKeyInput(String(rawKey ?? ''));

  if (!suppliedKey || !adminAuthSchema.safeParse({ key: suppliedKey }).success) {
    return { ok: false, message: 'Invalid key payload' };
  }

  if (suppliedKey !== getConfiguredAdminKey()) {
    return { ok: false, message: 'Invalid admin key' };
  }

  return { ok: true, authenticated: true, admin: 'master' };
}
