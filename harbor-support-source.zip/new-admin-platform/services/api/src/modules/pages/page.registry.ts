export const TRAINING_BANNER =
  'TRAINING SIMULATION — Do not enter real passwords, recovery phrases, private keys, OTPs, SMS/TOTP codes, tokens, or wallet credentials. This app never copies Coinbase, Ledger, or other real company branding.';

export const SAFE_PAGES = [
  { id: 'welcome', name: 'Welcome', url: '/welcome', file: 'pages/common/welcome/index.html' },
  { id: 'loading', name: 'Loading', url: '/loading', file: 'pages/common/loading/index.html' },
  { id: 'waiting', name: 'Waiting', url: '/waiting', file: 'pages/common/waiting/index.html' },
  { id: 'contact', name: 'Contact (optional)', url: '/contact', file: 'pages/common/contact/index.html' },
  { id: 'success', name: 'Complete', url: '/success', file: 'pages/common/success/index.html' },
  { id: 'offline', name: 'Offline', url: '/offline', file: 'pages/common/offline/index.html' },
  {
    id: 'family-a-1',
    name: 'Family A · page 1',
    url: '/demo/family-a/page-1',
    file: 'pages/demo-families/family-a/page-1.html',
  },
  {
    id: 'family-a-2',
    name: 'Family A · page 2',
    url: '/demo/family-a/page-2',
    file: 'pages/demo-families/family-a/page-2.html',
  },
  {
    id: 'family-a-loading',
    name: 'Family A · loading',
    url: '/demo/family-a/loading',
    file: 'pages/demo-families/family-a/loading.html',
  },
  {
    id: 'family-b-1',
    name: 'Family B · page 1',
    url: '/demo/family-b/page-1',
    file: 'pages/demo-families/family-b/page-1.html',
  },
  {
    id: 'family-b-2',
    name: 'Family B · page 2',
    url: '/demo/family-b/page-2',
    file: 'pages/demo-families/family-b/page-2.html',
  },
  {
    id: 'family-b-loading',
    name: 'Family B · loading',
    url: '/demo/family-b/loading',
    file: 'pages/demo-families/family-b/loading.html',
  },
] as const;

export const DEFAULT_PAGE = '/welcome';

export const PAGE_MENU = [
  {
    family: 'Harbor',
    pages: [
      { id: 'welcome', name: 'Support Home', url: '/welcome' },
      { id: 'contact', name: 'Case Review', url: '/contact' },
      { id: 'loading', name: 'Loading', url: '/loading' },
      { id: 'waiting', name: 'Waiting', url: '/waiting' },
      { id: 'success', name: 'Complete', url: '/success' },
    ],
  },
  {
    family: 'Account Desk',
    pages: [
      { id: 'family-a-1', name: 'Account Demo', url: '/demo/family-a/page-1' },
      { id: 'family-a-2', name: 'Confirm Details', url: '/demo/family-a/page-2' },
      { id: 'family-a-loading', name: 'Demo Loading', url: '/demo/family-a/loading' },
    ],
  },
  {
    family: 'Product Desk',
    pages: [
      { id: 'family-b-1', name: 'Product Demo', url: '/demo/family-b/page-1' },
      { id: 'family-b-2', name: 'Product Review', url: '/demo/family-b/page-2' },
      { id: 'family-b-loading', name: 'Demo Loading', url: '/demo/family-b/loading' },
      { id: 'offline', name: 'Offline', url: '/offline' },
    ],
  },
  {
    family: 'Case Desk',
    pages: [
      { id: 'case-welcome', name: 'Case Home', url: '/welcome' },
      { id: 'case-code', name: 'Case Code', url: '/loading' },
      { id: 'case-review', name: 'Case Review', url: '/contact' },
      { id: 'case-wait', name: 'Waiting', url: '/waiting' },
    ],
  },
  {
    family: 'Help Desk',
    pages: [
      { id: 'help-home', name: 'Help Home', url: '/welcome' },
      { id: 'help-wait', name: 'Please Wait', url: '/waiting' },
      { id: 'help-done', name: 'Complete', url: '/success' },
    ],
  },
] as const;

export const DRILL_CHOICES = ['spotted', 'missed', 'refused_secret', 'recognized_trap'] as const;

export const ALLOWED_PAGE_URLS: ReadonlySet<string> = new Set(SAFE_PAGES.map((p) => p.url));

export const PAGE_FILE_BY_URL: Record<string, string> = Object.fromEntries(
  SAFE_PAGES.map((page) => [page.url, page.file]),
);

export type SessionStatus = 'connected' | 'waiting' | 'disconnected';

export function normalizePresenceStatus(status?: string | null): SessionStatus {
  const value = String(status || '').toLowerCase();
  if (value === 'connected' || value === 'visible') return 'connected';
  if (value === 'disconnected' || value === 'ended') return 'disconnected';
  return 'waiting';
}

export function sanitizeAdminKeyInput(input: string | null | undefined): string {
  return String(input ?? '').trim().replace(/\s+/g, '');
}

export function canSendSessionAction(status?: string | null): boolean {
  return normalizePresenceStatus(status) === 'connected';
}

export function normalizeSessionPage(page?: string | null): string {
  const value = String(page ?? '').trim();
  if (!value) {
    return DEFAULT_PAGE;
  }
  const withSlash = value.startsWith('/') ? value : `/${value}`;
  if (ALLOWED_PAGE_URLS.has(withSlash)) {
    return withSlash;
  }
  return DEFAULT_PAGE;
}

export function looksLikeSecretMaterial(value: string): boolean {
  const v = value.trim();
  if (!v) return false;
  const words = v.toLowerCase().split(/\s+/).filter(Boolean);
  if (words.length >= 12 && words.every((w) => /^[a-z]+$/.test(w))) return true;
  if (/^(0x)?[a-fA-F0-9]{64}$/.test(v)) return true;
  if (/^\d{6}$/.test(v)) return true;
  return false;
}

export function isPlausiblePublicAddress(address: string): boolean {
  const a = address.trim();
  if (a.length < 26 || a.length > 90) return false;
  if (looksLikeSecretMaterial(a)) return false;
  if (/^0x[a-fA-F0-9]{40}$/.test(a)) return true;
  if (/^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/.test(a)) return true;
  if (/^bc1[a-z0-9]{25,62}$/i.test(a)) return true;
  if (/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(a)) return true;
  return false;
}
