import type { Server } from 'socket.io';
import {
  ALLOWED_PAGE_URLS,
  canSendSessionAction,
  normalizeSessionPage,
} from '../pages/page.registry.js';
import { draftToApplied, type AdminDraft } from '../state/core-state.js';
import { logVisitorEvent } from '../events/event.service.js';
import {
  applyAppliedVisitorState,
  getVisitorByToken,
  toAdminSession,
} from '../sessions/session.repository.js';
import { emitToAdmins, emitToSession } from '../../realtime/broadcast.js';
import { REALTIME_EVENTS } from '../../realtime/events.js';
import type { SendCommand } from './send.types.js';

/**
 * AdminDraft → validate → DB transaction (AppliedVisitorState) → WebSocket.
 * Preview never enters the applied path.
 */
export async function applyAdminCommand(
  io: Server,
  command: SendCommand,
  broadcastSessions: () => Promise<void>,
) {
  const currentSession = await getVisitorByToken(command.sessionToken);
  if (!currentSession) {
    return { ok: false as const, status: 404, message: 'Session not found' };
  }

  // Authority boundary: only DB presence counts. Client-supplied status is ignored.
  // Preview stays read-only; send and redirect both require Connected.
  if (command.action !== 'preview' && !canSendSessionAction(currentSession.status)) {
    return {
      ok: false as const,
      status: 409,
      message: 'Session must be connected before send. Waiting does not queue Send.',
    };
  }

  const normalizedPage = normalizeSessionPage(command.page ?? currentSession.current_page);
  if (command.page && !ALLOWED_PAGE_URLS.has(normalizedPage)) {
    return { ok: false as const, status: 400, message: 'Unknown support screen' };
  }

  const draft: AdminDraft = {
    selectedFamily: command.selectedFamily || '',
    selectedPage: normalizedPage,
    selectedAction: command.action,
    temporaryParameters: command.temporaryParameters || {},
  };

  // Preview: AdminDraft inspection only. No AppliedVisitorState. No WS.
  if (command.action === 'preview') {
    await logVisitorEvent(currentSession.id, 'admin:preview', { page: draft.selectedPage });
    return {
      ok: true as const,
      preview: true,
      page: draft.selectedPage,
      draft,
      session: currentSession,
    };
  }

  const applied = draftToApplied(draft, command.action);
  const session = await applyAppliedVisitorState(command.sessionToken, applied);
  if (!session) {
    return { ok: false as const, status: 404, message: 'Session not found' };
  }

  await logVisitorEvent(session.id, `admin:${command.action}`, {
    page: session.current_page,
    status: session.status,
    applied,
  });

  const adminRow = toAdminSession(session);
  emitToAdmins(io, REALTIME_EVENTS.sessionPatch, adminRow);
  await broadcastSessions();

  emitToSession(io, command.sessionToken, REALTIME_EVENTS.sessionCommand, {
    sessionToken: command.sessionToken,
    action: command.action,
    page: applied.currentPage,
    status: session.status,
    applied,
    at: new Date().toISOString(),
  });

  return { ok: true as const, session, applied };
}
