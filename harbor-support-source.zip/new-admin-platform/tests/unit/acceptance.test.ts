import test from 'node:test';
import assert from 'node:assert/strict';

import {
  canSendSessionAction,
  mergeSessionRow,
  presenceFromVisibility,
  presenceLabel,
} from '../../packages/session-rules/src/index.ts';

test('visible tab is Connected; hidden tab is Waiting', () => {
  assert.equal(presenceFromVisibility('visible'), 'connected');
  assert.equal(presenceFromVisibility('hidden'), 'waiting');
  assert.equal(presenceFromVisibility('prerender'), 'waiting');
  assert.equal(presenceLabel('idle'), 'Waiting');
  assert.equal(presenceLabel('waiting'), 'Waiting');
});

test('Waiting blocks Send; Connected allows Send', () => {
  assert.equal(canSendSessionAction('waiting'), false);
  assert.equal(canSendSessionAction('idle'), false);
  assert.equal(canSendSessionAction('connected'), true);
});

test('mergeSessionRow updates only the matching Admin row', () => {
  const rows = [
    { token: 'a', status: 'connected', currentPage: '/welcome', demoName: '' },
    { token: 'b', status: 'waiting', currentPage: '/waiting', demoName: '' },
  ];
  const next = mergeSessionRow(rows, {
    token: 'b',
    status: 'waiting',
    currentPage: '/waiting',
    demoName: 'Sergio',
  });
  assert.equal(next[0].demoName, '');
  assert.equal(next[0].status, 'connected');
  assert.equal(next[1].demoName, 'Sergio');
  assert.equal(next[0], rows[0]);
});

test('mergeSessionRow inserts unknown tokens at the front', () => {
  const rows = [{ token: 'a', status: 'connected' }];
  const next = mergeSessionRow(rows, { token: 'new', status: 'waiting' });
  assert.equal(next[0].token, 'new');
  assert.equal(next.length, 2);
});

test('Waiting Send gate uses server presence only (client status ignored)', () => {
  const dbStatus = 'waiting';
  const forgedClientStatus = 'connected';
  assert.equal(canSendSessionAction(dbStatus), false);
  assert.equal(canSendSessionAction(forgedClientStatus), true);
});
