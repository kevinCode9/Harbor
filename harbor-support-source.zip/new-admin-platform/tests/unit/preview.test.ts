import test from 'node:test';
import assert from 'node:assert/strict';
import { createEmptyAdminDraft, selectDraftAction } from '../../packages/core-state/src/index.ts';
import { normalizeSessionPage } from '../../packages/session-rules/src/index.ts';

test('Preview keeps AdminDraft and does not produce applied state', () => {
  const draft = createEmptyAdminDraft('/welcome');
  const next = selectDraftAction(draft, 'preview');
  assert.equal(next.selectedAction, 'preview');
  assert.equal(next.selectedPage, '/welcome');
  assert.equal(draft.selectedAction, null);
});

test('preview iframe uses preview=1 so the visitor does not join', () => {
  assert.equal(`${normalizeSessionPage('/waiting')}?preview=1`, '/waiting?preview=1');
  assert.equal(`${normalizeSessionPage('/coinbase/signin')}?preview=1`, '/welcome?preview=1');
});
